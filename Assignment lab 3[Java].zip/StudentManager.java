import java.util.*;

public class StudentManager implements RecordActions {

    private HashMap<Integer, Student> db = new HashMap<>();
    Scanner sc = new Scanner(System.in);

    @Override
    public void addStudent() {
        try {
            System.out.print("Enter Roll No (Integer): ");
            Integer roll = Integer.parseInt(sc.nextLine());   // autoboxing

            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            if (name.isEmpty()) throw new Exception("Name cannot be empty");

            System.out.print("Enter Email: ");
            String email = sc.nextLine();
            if (email.isEmpty()) throw new Exception("Email cannot be empty");

            System.out.print("Enter Course: ");
            String course = sc.nextLine();
            if (course.isEmpty()) throw new Exception("Course cannot be empty");

            System.out.print("Enter Marks: ");
            Double marks = Double.parseDouble(sc.nextLine());  // autoboxing
            if (marks < 0 || marks > 100)
                throw new Exception("Marks must be between 0 and 100!");

            // Loading simulation
            Thread t = new Thread(new Loader());
            t.start();
            t.join();

            Student st = new Student(roll, name, email, course, marks);
            db.put(roll, st);

            System.out.println("\nStudent Added Successfully!");
            st.printDetails();

        } catch (NumberFormatException e) {
            System.out.println("Invalid number entered.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("\nProgram execution completed.");
        }
    }

    @Override
    public void displayStudent(int rollNo) throws StudentNotFoundException {
        if (!db.containsKey(rollNo))
            throw new StudentNotFoundException("Student Not Found!");
        db.get(rollNo).printDetails();
    }
}
