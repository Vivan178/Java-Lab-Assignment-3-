import java.util.*;

public class Main {
    public static void main(String[] args) {
        StudentManager sm = new StudentManager();
        Scanner sc = new Scanner(System.in);

        sm.addStudent();

        System.out.println("\nEnter Roll No to Display:");
        int r = sc.nextInt();

        try {
            sm.displayStudent(r);
        } catch (StudentNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
}
