public class Loader implements Runnable {

    @Override
    public void run() {
        System.out.print("Loading");
        try {
            for (int i = 0; i < 5; i++) {
                Thread.sleep(400);
                System.out.print(".");
            }
        } catch (InterruptedException e) {
            System.out.println("Loading interrupted!");
        }
        System.out.println();
    }
}
