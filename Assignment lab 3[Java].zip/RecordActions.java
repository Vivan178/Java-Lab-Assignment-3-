public interface RecordActions {
    void addStudent();
    void displayStudent(int rollNo) throws StudentNotFoundException;
}
